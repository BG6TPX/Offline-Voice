#ifndef FYY_DELAY__H
#define FYY_DELAY__H

void delay_init(u8 SYSCLK);
void delay_us(u32 nus);
void sys_delay_ms(u16 nms);


#endif
